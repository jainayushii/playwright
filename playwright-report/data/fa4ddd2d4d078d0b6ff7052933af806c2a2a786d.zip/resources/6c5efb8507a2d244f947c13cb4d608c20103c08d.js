/* Polyfill service v4.8.0
 * For detailed credits and licence information see https://github.com/financial-times/polyfill-service.
 * 
 * Features requested: DOMTokenList.prototype.@@iterator,DOMTokenList.prototype.forEach,NodeList.prototype.@@iterator,NodeList.prototype.forEach,Reflect,Reflect.construct,Symbol.prototype.description,TextDecoder,TextEncoder,URL,URL.prototype.toJSON,es2015,es2016,es2017,es2018,es2019,es2020,es2021,es2022,es2023
 *  */


/* No polyfills needed for current settings and browser */

